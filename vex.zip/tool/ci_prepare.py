#!/usr/bin/env python3
"""آماده‌سازی پروژه‌ی اندروید بعد از `flutter create` (اجرا در GitHub Actions):
مانیفست، MainActivity، آیکون‌ها، تنظیمات Gradle و دانلود فونت‌ها."""
import pathlib
import re
import shutil
import sys
import urllib.request

ROOT = pathlib.Path('.')
ANDROID = ROOT / 'android'


def log(msg):
    print(f'[ci_prepare] {msg}', flush=True)


def manifest():
    shutil.copy(ROOT / 'android_overrides/AndroidManifest.xml', ANDROID / 'app/src/main/AndroidManifest.xml')
    log('AndroidManifest.xml replaced')


def main_activity():
    found = list((ANDROID / 'app/src/main').rglob('MainActivity.kt'))
    if not found:
        log('ERROR: MainActivity.kt not found')
        sys.exit(1)
    target = found[0]
    text = target.read_text(encoding='utf-8')
    m = re.search(r'^package\s+([\w.]+)', text, re.M)
    pkg = m.group(1) if m else 'com.vex.vex_app'
    tpl = (ROOT / 'android_overrides/MainActivity.kt').read_text(encoding='utf-8')
    target.write_text(tpl.replace('__PACKAGE__', pkg), encoding='utf-8')
    log(f'MainActivity.kt patched (package {pkg})')


def icons():
    res = ANDROID / 'app/src/main/res'
    # آیکون‌های پیش‌فرض فلاتر (webp/png) را پاک می‌کنیم تا فقط لوگوی Vex بماند
    for d in res.glob('mipmap-*'):
        for f in d.glob('ic_launcher*'):
            f.unlink()
    shutil.copytree(ROOT / 'android_res', res, dirs_exist_ok=True)
    log('launcher icons + styles copied')


def gradle():
    kts = ANDROID / 'app/build.gradle.kts'
    groovy = ANDROID / 'app/build.gradle'
    if kts.exists():
        s = kts.read_text(encoding='utf-8')
        s = re.sub(r'minSdk\s*=\s*flutter\.minSdkVersion', 'minSdk = 24', s)
        if 'isMinifyEnabled' not in s:
            s = re.sub(r'(buildTypes\s*\{\s*release\s*\{)', r'\1\n            isMinifyEnabled = false\n            isShrinkResources = false', s, count=1)
        kts.write_text(s, encoding='utf-8')
        log('build.gradle.kts patched')
    elif groovy.exists():
        s = groovy.read_text(encoding='utf-8')
        s = re.sub(r'minSdkVersion\s+flutter\.minSdkVersion', 'minSdkVersion 24', s)
        s = re.sub(r'minSdk\s*=?\s*flutter\.minSdkVersion', 'minSdk 24', s)
        if 'minifyEnabled' not in s:
            s = re.sub(r'(buildTypes\s*\{\s*release\s*\{)', r'\1\n            minifyEnabled false\n            shrinkResources false', s, count=1)
        groovy.write_text(s, encoding='utf-8')
        log('build.gradle patched')
    else:
        log('ERROR: no app/build.gradle(.kts) found')
        sys.exit(1)


def compile_sdk():
    """همه‌ی پلاگین‌ها و خود برنامه با compileSdk 36 ساخته شوند (اسکریپت init گریدل)."""
    d = pathlib.Path.home() / '.gradle' / 'init.d'
    d.mkdir(parents=True, exist_ok=True)
    (d / 'vex_compile_sdk.gradle').write_text(
        "allprojects {\n"
        "    afterEvaluate { p ->\n"
        "        if (p.hasProperty('android')) {\n"
        "            p.android.compileSdk = 36\n"
        "        }\n"
        "    }\n"
        "}\n",
        encoding='utf-8')
    log('gradle init script: compileSdk 36 for all modules')


GF = 'https://github.com/google/fonts/raw/main/ofl'
GFC = 'https://cdn.jsdelivr.net/gh/google/fonts@main/ofl'
VAZ = 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@master/fonts/ttf'
VAZ2 = 'https://github.com/rastikerdar/vazirmatn/raw/master/fonts/ttf'
EST = 'aminabedi68/Estedad'


def estedad(weight):
    out = []
    for ref in ('master', 'main'):
        for sub in ('fonts/ttf', 'fonts/TTF', 'fonts/static', 'fonts', 'dist/ttf', 'ttf'):
            out.append(f'https://cdn.jsdelivr.net/gh/{EST}@{ref}/{sub}/Estedad-{weight}.ttf')
            out.append(f'https://github.com/{EST}/raw/{ref}/{sub}/Estedad-{weight}.ttf')
    return out


FONT_SOURCES = {
    'Estedad-Regular.ttf': estedad('Regular'),
    'Estedad-Medium.ttf': estedad('Medium'),
    'Estedad-SemiBold.ttf': estedad('SemiBold'),
    'Estedad-Bold.ttf': estedad('Bold'),
    'Vazirmatn-Regular.ttf': [f'{VAZ}/Vazirmatn-Regular.ttf', f'{VAZ2}/Vazirmatn-Regular.ttf'],
    'Vazirmatn-Medium.ttf': [f'{VAZ}/Vazirmatn-Medium.ttf', f'{VAZ2}/Vazirmatn-Medium.ttf'],
    'Vazirmatn-SemiBold.ttf': [f'{VAZ}/Vazirmatn-SemiBold.ttf', f'{VAZ2}/Vazirmatn-SemiBold.ttf'],
    'Vazirmatn-Bold.ttf': [f'{VAZ}/Vazirmatn-Bold.ttf', f'{VAZ2}/Vazirmatn-Bold.ttf'],
    'Michroma-Regular.ttf': [f'{GF}/michroma/Michroma-Regular.ttf', f'{GFC}/michroma/Michroma-Regular.ttf'],
}


def fetch(urls, dest):
    for u in urls:
        try:
            with urllib.request.urlopen(u, timeout=20) as r:
                data = r.read()
            if len(data) > 10_000 and data[:4] in (b'\x00\x01\x00\x00', b'true', b'OTTO'):
                dest.write_bytes(data)
                return True
            log(f'  not a font: {u}')
        except Exception as e:  # noqa: BLE001
            log(f'  failed {u}: {e}')
    return False


def fonts():
    out = ROOT / 'assets/fonts'
    out.mkdir(parents=True, exist_ok=True)
    got = {}
    for name, urls in FONT_SOURCES.items():
        ok = fetch(urls, out / name)
        got[name] = ok
        log(f'font {name}: {"ok" if ok else "MISSING (will fall back)"}')
    lines = ['', '  fonts:']

    def family(fam, files):
        have = [(n, w) for n, w in files if got.get(n)]
        if not have:
            return
        lines.extend([f'    - family: {fam}', '      fonts:'])
        for n, w in have:
            lines.append(f'        - asset: assets/fonts/{n}')
            if w:
                lines.append(f'          weight: {w}')

    family('Estedad', [('Estedad-Regular.ttf', 400), ('Estedad-Medium.ttf', 500),
                       ('Estedad-SemiBold.ttf', 600), ('Estedad-Bold.ttf', 700)])
    family('Vazirmatn', [('Vazirmatn-Regular.ttf', 400), ('Vazirmatn-Medium.ttf', 500),
                         ('Vazirmatn-SemiBold.ttf', 600), ('Vazirmatn-Bold.ttf', 700)])
    family('Michroma', [('Michroma-Regular.ttf', 0)])
    if len(lines) > 2:
        pub = ROOT / 'pubspec.yaml'
        text = pub.read_text(encoding='utf-8').rstrip('\n') + '\n' + '\n'.join(lines) + '\n'
        pub.write_text(text, encoding='utf-8')
        log('pubspec.yaml: fonts section added')


if __name__ == '__main__':
    manifest()
    main_activity()
    icons()
    gradle()
    compile_sdk()
    fonts()
    log('done')
