import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

import 'db.dart';

/// قفل برنامه، پنهان‌سازی و تنظیمات امنیتی
class Security extends ChangeNotifier {
  Security._();
  static final Security i = Security._();

  static const MethodChannel _ch = MethodChannel('vex/native');
  final LocalAuthentication _auth = LocalAuthentication();

  String mode = 'off'; // off | pin | device
  int pinLen = 4;
  String _pinHash = '';
  String _pinSalt = '';
  bool bio = false;
  bool hideMedia = true;
  bool secureFlag = true;
  int autoLockSec = 30;

  bool locked = false;
  bool started = false; // بعد از پایان اسپلش
  bool revealAll = false; // نمایش موقت همه‌ی فایل‌ها
  int fails = 0;
  int lockedUntil = 0;

  bool get hasPin => _pinHash.isNotEmpty;

  Future<void> load() async {
    final d = Db.i;
    mode = (await d.kvGet('lock_mode')) ?? 'off';
    pinLen = int.tryParse((await d.kvGet('pin_len')) ?? '') ?? 4;
    _pinHash = (await d.kvGet('pin_hash')) ?? '';
    _pinSalt = (await d.kvGet('pin_salt')) ?? '';
    bio = (await d.kvGet('bio')) == '1';
    hideMedia = (await d.kvGet('hide_media')) != '0';
    secureFlag = (await d.kvGet('secure_flag')) != '0';
    autoLockSec = int.tryParse((await d.kvGet('auto_lock')) ?? '') ?? 30;
    fails = int.tryParse((await d.kvGet('fails')) ?? '') ?? 0;
    lockedUntil = int.tryParse((await d.kvGet('locked_until')) ?? '') ?? 0;
    if (mode == 'pin' && !hasPin) mode = 'off';
    locked = mode != 'off';
    await applySecure();
  }

  Future<void> applySecure() async {
    try {
      await _ch.invokeMethod<bool>('secure', <String, Object?>{'on': secureFlag});
    } catch (_) {}
  }

  String _hash(String pin, String salt) {
    var d = utf8.encode('$salt:$pin');
    for (var i = 0; i < 3000; i++) {
      d = sha256.convert(d).bytes;
    }
    return base64.encode(d);
  }

  Future<void> setPin(String pin) async {
    final r = Random.secure();
    _pinSalt = base64.encode(List<int>.generate(12, (_) => r.nextInt(256)));
    _pinHash = _hash(pin, _pinSalt);
    pinLen = pin.length;
    await Db.i.kvSet('pin_salt', _pinSalt);
    await Db.i.kvSet('pin_hash', _pinHash);
    await Db.i.kvSet('pin_len', '$pinLen');
    notifyListeners();
  }

  bool checkPinOnly(String pin) => _hash(pin, _pinSalt) == _pinHash;

  int get remainingLockMs => max(0, lockedUntil - DateTime.now().millisecondsSinceEpoch);

  /// ورود با رمز؛ بعد از چند بار اشتباه، تأخیر فزاینده
  Future<bool> tryPin(String pin) async {
    if (remainingLockMs > 0) return false;
    if (checkPinOnly(pin)) {
      await unlock();
      return true;
    }
    fails++;
    if (fails >= 3) {
      final ms = min(900000, 30000 * (1 << min(fails - 3, 10)));
      lockedUntil = DateTime.now().millisecondsSinceEpoch + ms;
    }
    await Db.i.kvSet('fails', '$fails');
    await Db.i.kvSet('locked_until', '$lockedUntil');
    notifyListeners();
    return false;
  }

  Future<bool> deviceAuth(String reason) async {
    try {
      if (!await _auth.isDeviceSupported()) return false;
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(biometricOnly: false, stickyAuth: true),
      );
    } catch (_) {
      return false;
    }
  }

  Future<bool> bioAvailable() async {
    try {
      return await _auth.canCheckBiometrics;
    } catch (_) {
      return false;
    }
  }

  Future<void> unlock() async {
    locked = false;
    fails = 0;
    lockedUntil = 0;
    await Db.i.kvSet('fails', '0');
    await Db.i.kvSet('locked_until', '0');
    notifyListeners();
  }

  void lock() {
    revealAll = false;
    if (mode != 'off') locked = true;
    notifyListeners();
  }

  void markStarted() {
    started = true;
    notifyListeners();
  }

  void setReveal(bool v) {
    revealAll = v;
    notifyListeners();
  }

  Future<void> setMode(String m) async {
    mode = m;
    await Db.i.kvSet('lock_mode', m);
    notifyListeners();
  }

  Future<void> setBio(bool v) async {
    bio = v;
    await Db.i.kvSet('bio', v ? '1' : '0');
    notifyListeners();
  }

  Future<void> setHide(bool v) async {
    hideMedia = v;
    await Db.i.kvSet('hide_media', v ? '1' : '0');
    notifyListeners();
  }

  Future<void> setSecureFlag(bool v) async {
    secureFlag = v;
    await Db.i.kvSet('secure_flag', v ? '1' : '0');
    await applySecure();
    notifyListeners();
  }

  Future<void> setAutoLock(int sec) async {
    autoLockSec = sec;
    await Db.i.kvSet('auto_lock', '$sec');
    notifyListeners();
  }
}
