import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../../core/theme.dart';
import '../../core/util.dart';
import '../../data/db.dart';
import '../../data/vault.dart';
import '../widgets.dart';
import 'item_pages.dart';
import 'search_page.dart';

void openPerson(BuildContext context, int id) {
  Navigator.push(context, MaterialPageRoute<void>(builder: (_) => PersonPage(id: id)));
}

// ───────────────────────── تب اشخاص ─────────────────────────

class PersonsPage extends StatefulWidget {
  const PersonsPage({super.key});
  @override
  State<PersonsPage> createState() => _PersonsPageState();
}

class _PersonsPageState extends State<PersonsPage> {
  final TextEditingController _q = TextEditingController();

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: DbBuilder<Snap>(
          load: Db.i.all,
          builder: (c, s) {
            final q = normFa(_q.text.trim());
            final list = s.persons.where((e) => q.isEmpty || normFa('${e.name} ${e.alias} ${e.notes}').contains(q)).toList();
            final counts = <int, int>{};
            for (final it in s.items) {
              for (final id in it.personIds) {
                counts[id] = (counts[id] ?? 0) + 1;
              }
            }
            return Column(children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
                child: Row(children: [
                  const Hud('PERSONS'),
                  const SizedBox(width: 10),
                  Text('${faDigits(s.persons.length)} شخص', style: const TextStyle(color: V.textDim, fontSize: 12)),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.person_add_alt_1_outlined, color: V.cyan),
                    onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => const PersonEditorPage())),
                  ),
                ]),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: VField(controller: _q, label: 'جستجو در اشخاص', onChanged: (_) => setState(() {})),
              ),
              Expanded(
                child: list.isEmpty
                    ? EmptyState(icon: Icons.groups_outlined, text: s.persons.isEmpty ? 'هنوز شخصی ثبت نشده.\nبا دکمه‌ی بالا اولین شخص را اضافه کنید.' : 'شخصی پیدا نشد.')
                    : GridView.builder(
                        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: .78),
                        itemCount: list.length,
                        itemBuilder: (c, i) {
                          final x = list[i];
                          return VexCard(
                            padding: const EdgeInsets.all(10),
                            onTap: () => openPerson(context, x.id),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Expanded(child: SizedBox(width: double.infinity, child: PersonAvatar(person: x, bracket: true))),
                              const SizedBox(height: 8),
                              Text(x.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.text, fontWeight: FontWeight.w700)),
                              Row(children: [
                                Expanded(
                                  child: Text(x.alias.isEmpty ? x.code : x.alias,
                                      maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.textDim, fontSize: 11)),
                                ),
                                Icon(Icons.folder_outlined, size: 13, color: V.silverDim),
                                const SizedBox(width: 3),
                                Text(faDigits(counts[x.id] ?? 0), style: const TextStyle(color: V.silverDim, fontSize: 11)),
                              ]),
                            ]),
                          );
                        },
                      ),
              ),
            ]);
          },
        ),
      );
}

// ───────────────────────── پرونده‌ی شخص ─────────────────────────

class PersonPage extends StatelessWidget {
  const PersonPage({super.key, required this.id});
  final int id;

  @override
  Widget build(BuildContext context) => Scaffold(
        body: DbBuilder<Snap>(
          load: Db.i.all,
          builder: (c, s) {
            final x = s.pmap[id];
            if (x == null) {
              return SafeArea(child: Column(children: [
                Align(alignment: AlignmentDirectional.centerStart, child: BackButton(onPressed: () => Navigator.pop(context))),
                const Expanded(child: EmptyState(icon: Icons.person_off_outlined, text: 'این شخص دیگر وجود ندارد.')),
              ]));
            }
            return _PersonView(person: x, snap: s);
          },
        ),
      );
}

class _PersonView extends StatelessWidget {
  const _PersonView({required this.person, required this.snap});
  final Person person;
  final Snap snap;

  @override
  Widget build(BuildContext context) {
    final items = snap.itemsOf(person.id);
    final places = snap.places.where((e) => e.personId == person.id).toList();
    return DefaultTabController(
      length: 4,
      child: SafeArea(
        child: Column(children: [
          Row(children: [
            BackButton(onPressed: () => Navigator.pop(context)),
            Hud(person.code),
            const Spacer(),
            IconButton(
              icon: const Icon(Icons.edit_outlined, color: V.silver),
              onPressed: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => PersonEditorPage(person: person))),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, color: V.danger),
              onPressed: () async {
                final ok = await confirmDialog(context, 'انتقال به سطل بازیافت؟', 'پرونده‌های مرتبط حذف نمی‌شوند.', ok: 'حذف', danger: true);
                if (ok) {
                  await Db.i.trashPerson(person.id);
                  if (context.mounted) Navigator.pop(context);
                }
              },
            ),
          ]),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SizedBox(width: 104, height: 104, child: PersonAvatar(person: person, bracket: true)),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(person.name, style: const TextStyle(color: V.text, fontSize: 20, fontWeight: FontWeight.w800)),
                  if (person.alias.isNotEmpty) Text(person.alias, style: const TextStyle(color: V.textDim)),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 6, children: [
                    ConfChip(person.conf),
                    Text('${faDigits(items.length)} پرونده · ${faDigits(places.length)} مکان', style: const TextStyle(color: V.silverDim, fontSize: 12)),
                  ]),
                  if (person.notes.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(person.notes, maxLines: 4, overflow: TextOverflow.ellipsis, style: const TextStyle(color: V.textDim, fontSize: 12, height: 1.6)),
                  ],
                ]),
              ),
            ]),
          ),
          const TabBar(
            indicatorColor: V.cyan,
            labelColor: V.cyan,
            unselectedLabelColor: V.textDim,
            dividerColor: V.stroke,
            tabs: [Tab(text: 'پرونده‌ها'), Tab(text: 'مکان‌ها'), Tab(text: 'زمان‌نگار'), Tab(text: 'ارتباطات')],
          ),
          Expanded(
            child: TabBarView(children: [
              _ItemsTab(person: person, items: items, snap: snap),
              _PlacesTab(person: person, places: places),
              _TimelineTab(items: items, snap: snap),
              _RelationsTab(person: person, items: items, snap: snap),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _ItemsTab extends StatelessWidget {
  const _ItemsTab({required this.person, required this.items, required this.snap});
  final Person person;
  final List<Item> items;
  final Snap snap;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 30), children: [
        Wrap(spacing: 10, runSpacing: 10, children: [
          VButton(
            label: 'فایل جدید',
            icon: Icons.add,
            onTap: () async {
              final f = await pickFilesFromStorage();
              if (f.isEmpty || !context.mounted) return;
              Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ItemEditorPage(files: f, personId: person.id)));
            },
          ),
          VButton(
            label: 'یادداشت',
            icon: Icons.notes,
            filled: false,
            onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => ItemEditorPage(kind: 'note', personId: person.id))),
          ),
        ]),
        const SizedBox(height: 12),
        if (items.isEmpty)
          const Padding(padding: EdgeInsets.only(top: 40), child: EmptyState(icon: Icons.folder_open, text: 'هنوز فایلی برای این شخص ثبت نشده.'))
        else
          for (final it in items) Padding(padding: const EdgeInsets.only(bottom: 10), child: ItemTile(item: it, snap: snap, showSave: true)),
      ]);
}

class _PlacesTab extends StatelessWidget {
  const _PlacesTab({required this.person, required this.places});
  final Person person;
  final List<Place> places;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 30), children: [
        Align(
          alignment: AlignmentDirectional.centerStart,
          child: VButton(
            label: 'مکان جدید',
            icon: Icons.add_location_alt_outlined,
            onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => PlaceEditorPage(personId: person.id))),
          ),
        ),
        const SizedBox(height: 12),
        if (places.isEmpty)
          const Padding(padding: EdgeInsets.only(top: 40), child: EmptyState(icon: Icons.location_off_outlined, text: 'مکانی ثبت نشده (مثل منزل، محل کار، …).'))
        else
          for (final pl in places)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: VexCard(
                onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => PlaceEditorPage(personId: person.id, place: pl))),
                child: Row(children: [
                  const Icon(Icons.place_outlined, color: V.cyan),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(pl.title, style: const TextStyle(color: V.text, fontWeight: FontWeight.w600)),
                      if (pl.address.isNotEmpty) Text(pl.address, style: const TextStyle(color: V.textDim, fontSize: 12)),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text('${pl.lat.toStringAsFixed(5)}, ${pl.lng.toStringAsFixed(5)}', style: V.mono(size: 9, color: V.silverDim)),
                      ),
                    ]),
                  ),
                  IconButton(icon: const Icon(Icons.map_outlined, color: V.cyan), onPressed: () => openMap(context, pl.lat, pl.lng, pl.title)),
                ]),
              ),
            ),
      ]);
}

class _TimelineTab extends StatelessWidget {
  const _TimelineTab({required this.items, required this.snap});
  final List<Item> items;
  final Snap snap;
  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const EmptyState(icon: Icons.timeline, text: 'رویدادی برای نمایش نیست.');
    final sorted = List<Item>.of(items)..sort((a, b) => b.date.compareTo(a.date));
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 30),
      itemCount: sorted.length,
      itemBuilder: (c, i) {
        final it = sorted[i];
        return IntrinsicHeight(
          child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            SizedBox(
              width: 74,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(jalaliShort(it.dateTime), style: V.mono(size: 9, color: V.silverDim, spacing: 0.5)),
              ]),
            ),
            Column(children: [
              Container(width: 11, height: 11, decoration: BoxDecoration(color: V.confColors[it.conf.clamp(0, 3)], shape: BoxShape.circle)),
              Expanded(child: Container(width: 1.5, color: V.stroke)),
            ]),
            const SizedBox(width: 12),
            Expanded(child: Padding(padding: const EdgeInsets.only(bottom: 12), child: ItemTile(item: it, snap: snap))),
          ]),
        );
      },
    );
  }
}

class _RelationsTab extends StatelessWidget {
  const _RelationsTab({required this.person, required this.items, required this.snap});
  final Person person;
  final List<Item> items;
  final Snap snap;
  @override
  Widget build(BuildContext context) {
    final people = <int, int>{};
    final subjects = <String, int>{};
    final tags = <String, int>{};
    for (final it in items) {
      for (final id in it.personIds) {
        if (id != person.id) people[id] = (people[id] ?? 0) + 1;
      }
      if (it.subject.isNotEmpty) subjects[it.subject] = (subjects[it.subject] ?? 0) + 1;
      for (final t in it.tagList) {
        tags[t] = (tags[t] ?? 0) + 1;
      }
    }
    List<MapEntry<K, int>> sortE<K>(Map<K, int> m) {
      final l = m.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
      return l;
    }

    if (people.isEmpty && subjects.isEmpty && tags.isEmpty) {
      return const EmptyState(icon: Icons.hub_outlined, text: 'هنوز ارتباطی ثبت نشده.\nبا اتصال فایل‌ها به چند شخص یا موضوع، ارتباطات اینجا ظاهر می‌شود.');
    }
    return ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 30), children: [
      if (people.isNotEmpty) ...[
        const SectionTitle('اشخاص مشترک', hud: 'LINKS'),
        for (final e in sortE<int>(people))
          if (snap.pmap[e.key] != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: VexCard(
                onTap: () => openPerson(context, e.key),
                child: Row(children: [
                  PersonAvatar(person: snap.pmap[e.key]!, size: 40),
                  const SizedBox(width: 12),
                  Expanded(child: Text(snap.pmap[e.key]!.name, style: const TextStyle(color: V.text))),
                  Text('${faDigits(e.value)} پرونده‌ی مشترک', style: const TextStyle(color: V.cyan, fontSize: 12)),
                ]),
              ),
            ),
      ],
      if (subjects.isNotEmpty) ...[
        const SectionTitle('موضوع‌ها', hud: 'SUBJECTS'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in sortE<String>(subjects))
            TagChip('${e.key} · ${faDigits(e.value)}',
                onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => SearchPage(initial: e.key, standalone: true)))),
        ]),
      ],
      if (tags.isNotEmpty) ...[
        const SectionTitle('هشتگ‌ها', hud: 'TAGS'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in sortE<String>(tags))
            TagChip('${e.key} · ${faDigits(e.value)}',
                onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => SearchPage(initial: e.key, standalone: true)))),
        ]),
      ],
    ]);
  }
}

// ───────────────────────── ویرایش شخص ─────────────────────────

class PersonEditorPage extends StatefulWidget {
  const PersonEditorPage({super.key, this.person});
  final Person? person;
  @override
  State<PersonEditorPage> createState() => _PersonEditorPageState();
}

class _PersonEditorPageState extends State<PersonEditorPage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _alias = TextEditingController();
  final TextEditingController _notes = TextEditingController();
  int _conf = 0;
  String? _photo; // نام ذخیره‌شده‌ی فعلی
  String? _oldPhoto;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final x = widget.person;
    if (x != null) {
      _name.text = x.name;
      _alias.text = x.alias;
      _notes.text = x.notes;
      _conf = x.conf;
      _photo = x.photo;
      _oldPhoto = x.photo;
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _alias.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pick(ImageSource src) async {
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1400, imageQuality: 90);
    if (x == null) return;
    final stored = await Vault.store(x.path, 'photo.jpg');
    // عکس تازه‌انتخاب‌شده‌ی قبلی (ذخیره‌نشده) را پاک کن
    if (_photo != null && _photo != _oldPhoto) await Vault.shred(_photo);
    setState(() => _photo = stored);
  }

  void _photoSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: V.card,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.photo_library_outlined, color: V.cyan),
            title: const Text('انتخاب از گالری'),
            onTap: () {
              Navigator.pop(c);
              _pick(ImageSource.gallery);
            },
          ),
          ListTile(
            leading: const Icon(Icons.photo_camera_outlined, color: V.cyan),
            title: const Text('گرفتن عکس'),
            onTap: () {
              Navigator.pop(c);
              _pick(ImageSource.camera);
            },
          ),
          if (_photo != null)
            ListTile(
              leading: const Icon(Icons.delete_outline, color: V.danger),
              title: const Text('حذف عکس'),
              onTap: () async {
                Navigator.pop(c);
                if (_photo != _oldPhoto) await Vault.shred(_photo);
                setState(() => _photo = null);
              },
            ),
        ]),
      ),
    );
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      toast(context, 'نام را وارد کنید.');
      return;
    }
    setState(() => _busy = true);
    final x = widget.person ?? Person(name: name);
    x.name = name;
    x.alias = _alias.text.trim();
    x.notes = _notes.text.trim();
    x.conf = _conf;
    x.photo = _photo;
    await Db.i.savePerson(x);
    if (_oldPhoto != null && _oldPhoto != _photo) await Vault.shred(_oldPhoto);
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final preview = Person(name: _name.text, photo: _photo, conf: _conf);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: V.bg,
        title: Text(widget.person == null ? 'شخص جدید' : 'ویرایش شخص', style: const TextStyle(fontSize: 17)),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: VButton(label: 'ثبت', icon: Icons.check, onTap: _busy ? null : _save),
          ),
        ],
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 40), children: [
        Center(
          child: GestureDetector(
            onTap: _photoSheet,
            child: Stack(alignment: Alignment.bottomCenter, children: [
              SizedBox(width: 150, height: 150, child: PersonAvatar(person: preview, bracket: true)),
              Container(
                margin: const EdgeInsets.only(bottom: 2),
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                color: V.bg,
                child: const Text('عکس پروفایل', style: TextStyle(color: V.cyan, fontSize: 11)),
              ),
            ]),
          ),
        ),
        const SizedBox(height: 20),
        VField(controller: _name, label: 'نام', onChanged: (_) => setState(() {})),
        VField(controller: _alias, label: 'نام مستعار / عنوان'),
        VField(controller: _notes, label: 'توضیحات', maxLines: 8),
        const SectionTitle('سطح محرمانگی', hud: 'CLASSIFICATION'),
        ConfSelector(value: _conf, onChanged: (v) => setState(() => _conf = v)),
      ]),
    );
  }
}

// ───────────────────────── مکان شخص ─────────────────────────

class PlaceEditorPage extends StatefulWidget {
  const PlaceEditorPage({super.key, required this.personId, this.place});
  final int personId;
  final Place? place;
  @override
  State<PlaceEditorPage> createState() => _PlaceEditorPageState();
}

class _PlaceEditorPageState extends State<PlaceEditorPage> {
  final TextEditingController _title = TextEditingController();
  final TextEditingController _addr = TextEditingController();
  final TextEditingController _coord = TextEditingController();
  final TextEditingController _notes = TextEditingController();

  @override
  void initState() {
    super.initState();
    final x = widget.place;
    if (x != null) {
      _title.text = x.title;
      _addr.text = x.address;
      _coord.text = '${x.lat}, ${x.lng}';
      _notes.text = x.notes;
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _addr.dispose();
    _coord.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final c = parseLatLng(_coord.text);
    if (_title.text.trim().isEmpty) {
      toast(context, 'عنوان مکان را بنویسید (مثلاً منزل).');
      return;
    }
    if (c == null) {
      toast(context, 'مختصات معتبر نیست. نمونه: ۳۵٫۶۸۹۲، ۵۱٫۳۸۹۰ یا لینک نقشه.');
      return;
    }
    final x = widget.place ?? Place(personId: widget.personId, title: '', lat: 0, lng: 0);
    x.title = _title.text.trim();
    x.address = _addr.text.trim();
    x.lat = c[0];
    x.lng = c[1];
    x.notes = _notes.text.trim();
    await Db.i.savePlace(x);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          backgroundColor: V.bg,
          title: Text(widget.place == null ? 'مکان جدید' : 'ویرایش مکان', style: const TextStyle(fontSize: 17)),
          actions: [
            if (widget.place != null)
              IconButton(
                icon: const Icon(Icons.delete_outline, color: V.danger),
                onPressed: () async {
                  final ok = await confirmDialog(context, 'حذف مکان؟', 'این مکان برای همیشه حذف می‌شود.', ok: 'حذف', danger: true);
                  if (ok) {
                    await Db.i.deletePlace(widget.place!.id);
                    if (context.mounted) Navigator.pop(context);
                  }
                },
              ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: VButton(label: 'ثبت', icon: Icons.check, onTap: _save),
            ),
          ],
        ),
        body: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 40), children: [
          VField(controller: _title, label: 'عنوان (منزل، محل کار، …)'),
          VField(controller: _addr, label: 'نشانی', maxLines: 3),
          VField(controller: _coord, label: 'مختصات (عرض، طول)', hint: '35.6892, 51.3890', ltr: true),
          const Padding(
            padding: EdgeInsets.only(bottom: 12),
            child: Text(
              'مختصات را از برنامه‌ی نقشه کپی کنید و اینجا بچسبانید؛ لینک نقشه هم پذیرفته می‌شود.',
              style: TextStyle(color: V.textDim, fontSize: 12, height: 1.6),
            ),
          ),
          VField(controller: _notes, label: 'توضیحات', maxLines: 5),
        ]),
      );
}
