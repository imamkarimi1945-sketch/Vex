import 'package:flutter/material.dart';

import '../core/theme.dart';
import 'pages/item_pages.dart';
import 'pages/person_pages.dart';
import 'pages/search_page.dart';
import 'pages/system_pages.dart';
import 'widgets.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0; // 0 جستجو، 1 اشخاص، 2 پرونده‌ها، 3 سیستم

  void _add() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: V.card,
      builder: (c) {
        Widget tile(IconData ic, String t, String sub, VoidCallback f) => ListTile(
              leading: Icon(ic, color: V.cyan),
              title: Text(t, style: const TextStyle(color: V.text)),
              subtitle: Text(sub, style: const TextStyle(color: V.textDim, fontSize: 12)),
              onTap: () {
                Navigator.pop(c);
                f();
              },
            );
        void push(Widget w) => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => w));
        return SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SizedBox(height: 12),
            Text('ثبت جدید', style: V.mono(size: 11, color: V.silver)),
            const SizedBox(height: 6),
            tile(Icons.person_add_alt_1_outlined, 'شخص', 'پرونده‌ی شخص با عکس پروفایل', () => push(const PersonEditorPage())),
            tile(Icons.attach_file, 'فایل یا مدرک', 'عکس، فیلم، صدا، سند — یک یا چند فایل', () async {
              final f = await pickFilesFromStorage();
              if (f.isEmpty || !mounted) return;
              push(ItemEditorPage(files: f));
            }),
            tile(Icons.photo_camera_outlined, 'عکس با دوربین', 'ثبت مستقیم', () async {
              final f = await pickFromCamera();
              if (f.isEmpty || !mounted) return;
              push(ItemEditorPage(files: f));
            }),
            tile(Icons.notes, 'یادداشت متنی', 'متن آزاد', () => push(const ItemEditorPage(kind: 'note'))),
            tile(Icons.place_outlined, 'مکان', 'مختصات و عنوان', () => push(const ItemEditorPage(kind: 'location'))),
            const SizedBox(height: 8),
          ]),
        );
      },
    );
  }

  Widget _navItem(int idx, IconData ic, String label) {
    final on = _tab == idx;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _tab = idx),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(ic, color: on ? V.cyan : V.silverDim, size: 23),
            const SizedBox(height: 3),
            Text(label, style: TextStyle(color: on ? V.cyan : V.silverDim, fontSize: 10.5, fontWeight: on ? FontWeight.w700 : FontWeight.w400)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: IndexedStack(index: _tab, children: const [SearchPage(), PersonsPage(), FilesPage(), SystemPage()]),
        bottomNavigationBar: Container(
          decoration: const BoxDecoration(color: V.bg2, border: Border(top: BorderSide(color: V.stroke))),
          child: SafeArea(
            top: false,
            child: Row(children: [
              _navItem(0, Icons.search, 'جستجو'),
              _navItem(1, Icons.groups_outlined, 'اشخاص'),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Material(
                  color: V.a(V.accent, .22),
                  shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(14), side: const BorderSide(color: V.accent)),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(onTap: _add, child: const SizedBox(width: 54, height: 46, child: Icon(Icons.add, color: V.text, size: 28))),
                ),
              ),
              _navItem(2, Icons.folder_outlined, 'پرونده‌ها'),
              _navItem(3, Icons.shield_outlined, 'سیستم'),
            ]),
          ),
        ),
      );
}
