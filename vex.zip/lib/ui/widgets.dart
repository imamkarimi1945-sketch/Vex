import 'dart:io';
import 'dart:ui' show ImageFilter;

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shamsi_date/shamsi_date.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';
import '../core/util.dart';
import '../data/db.dart';
import '../data/security.dart';
import '../data/vault.dart';

// ───────────────────────── کمکی‌ها ─────────────────────────

void toast(BuildContext context, String msg) {
  final m = ScaffoldMessenger.maybeOf(context);
  m?.hideCurrentSnackBar();
  m?.showSnackBar(SnackBar(
    content: Text(msg, style: const TextStyle(color: V.text)),
    backgroundColor: V.cardHi,
    behavior: SnackBarBehavior.floating,
    duration: const Duration(seconds: 3),
  ));
}

Future<bool> confirmDialog(BuildContext context, String title, String body,
    {String ok = 'تأیید', bool danger = false}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      backgroundColor: V.card,
      shape: BeveledRectangleBorder(
          borderRadius: BorderRadius.circular(16), side: const BorderSide(color: V.stroke)),
      title: Text(title, style: const TextStyle(color: V.text, fontSize: 17)),
      content: Text(body, style: const TextStyle(color: V.textDim, height: 1.6)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('انصراف')),
        TextButton(
          onPressed: () => Navigator.pop(c, true),
          child: Text(ok, style: TextStyle(color: danger ? V.danger : V.cyan)),
        ),
      ],
    ),
  );
  return r ?? false;
}

IconData kindIcon(String k) {
  switch (k) {
    case 'image':
      return Icons.image_outlined;
    case 'video':
      return Icons.videocam_outlined;
    case 'audio':
      return Icons.graphic_eq;
    case 'note':
      return Icons.notes;
    case 'location':
      return Icons.place_outlined;
    default:
      return Icons.insert_drive_file_outlined;
  }
}

String kindName(String k) {
  switch (k) {
    case 'image':
      return 'تصویر';
    case 'video':
      return 'ویدیو';
    case 'audio':
      return 'صدا';
    case 'note':
      return 'یادداشت';
    case 'location':
      return 'مکان';
    default:
      return 'فایل';
  }
}

Future<void> openMap(BuildContext context, double lat, double lng, String label) async {
  final geo = Uri.parse('geo:$lat,$lng?q=$lat,$lng(${Uri.encodeComponent(label)})');
  try {
    if (await launchUrl(geo, mode: LaunchMode.externalApplication)) return;
  } catch (_) {}
  try {
    await launchUrl(Uri.parse('https://www.google.com/maps?q=$lat,$lng'), mode: LaunchMode.externalApplication);
  } catch (_) {
    if (context.mounted) toast(context, 'برنامه‌ی نقشه پیدا نشد.');
  }
}

Future<void> saveToGallery(BuildContext context, Item it) async {
  if (!it.hasFile) return;
  try {
    final tmp = await Vault.tempCopy(it.file!, it.origName);
    if (!await Gal.hasAccess()) {
      await Gal.requestAccess();
    }
    if (it.kind == 'video') {
      await Gal.putVideo(tmp);
    } else if (it.kind == 'image') {
      await Gal.putImage(tmp);
    } else {
      await Share.shareXFiles(<XFile>[XFile(tmp)]);
      return;
    }
    if (context.mounted) toast(context, 'در گالری ذخیره شد.');
  } catch (e) {
    if (context.mounted) toast(context, 'ذخیره در گالری انجام نشد.');
  }
}

Future<void> shareItem(BuildContext context, Item it) async {
  if (!it.hasFile) return;
  try {
    final tmp = await Vault.tempCopy(it.file!, it.origName);
    await Share.shareXFiles(<XFile>[XFile(tmp)]);
  } catch (_) {
    if (context.mounted) toast(context, 'اشتراک‌گذاری انجام نشد.');
  }
}

Future<void> openItemFile(BuildContext context, Item it) async {
  if (!it.hasFile) return;
  try {
    final tmp = await Vault.tempCopy(it.file!, it.origName);
    final r = await OpenFilex.open(tmp);
    if (r.type != ResultType.done && context.mounted) {
      toast(context, 'برنامه‌ای برای باز کردن این فایل پیدا نشد.');
    }
  } catch (_) {
    if (context.mounted) toast(context, 'باز کردن فایل انجام نشد.');
  }
}

// ───────────────────────── ساخت‌وساز ─────────────────────────

/// هر بار دیتابیس عوض شد دوباره بارگذاری می‌کند.
class DbBuilder<T> extends StatefulWidget {
  const DbBuilder({super.key, required this.load, required this.builder});
  final Future<T> Function() load;
  final Widget Function(BuildContext, T) builder;

  @override
  State<DbBuilder<T>> createState() => _DbBuilderState<T>();
}

class _DbBuilderState<T> extends State<DbBuilder<T>> {
  T? _data;
  bool _has = false;
  int _gen = 0;

  @override
  void initState() {
    super.initState();
    Db.i.tick.addListener(_reload);
    _reload();
  }

  @override
  void dispose() {
    Db.i.tick.removeListener(_reload);
    super.dispose();
  }

  Future<void> _reload() async {
    final g = ++_gen;
    final d = await widget.load();
    if (!mounted || g != _gen) return;
    setState(() {
      _data = d;
      _has = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (!_has) {
      return const Center(child: CircularProgressIndicator(strokeWidth: 2, color: V.cyan));
    }
    return widget.builder(context, _data as T);
  }
}

class Hud extends StatelessWidget {
  const Hud(this.text, {super.key, this.color = V.silverDim});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Text(text.toUpperCase(), style: V.mono(color: color));
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.hud, this.trailing});
  final String title;
  final String? hud;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 18, 4, 10),
        child: Row(children: [
          Container(width: 3, height: 16, color: V.accent),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(color: V.text, fontSize: 15, fontWeight: FontWeight.w700)),
          if (hud != null) ...[const SizedBox(width: 10), Hud(hud!)],
          const Spacer(),
          if (trailing != null) trailing!,
        ]),
      );
}

class VexCard extends StatelessWidget {
  const VexCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.onTap,
    this.onLongPress,
    this.color,
    this.borderColor,
  });
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final Color? color;
  final Color? borderColor;

  @override
  Widget build(BuildContext context) => Material(
        color: color ?? V.card,
        shape: BeveledRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(color: borderColor ?? V.stroke),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(onTap: onTap, onLongPress: onLongPress, child: Padding(padding: padding, child: child)),
      );
}

class _BracketPainter extends CustomPainter {
  _BracketPainter(this.color, this.len);
  final Color color;
  final double len;
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.square;
    final path = Path()
      ..moveTo(0, len)
      ..lineTo(0, 0)
      ..lineTo(len, 0)
      ..moveTo(s.width - len, 0)
      ..lineTo(s.width, 0)
      ..lineTo(s.width, len)
      ..moveTo(s.width, s.height - len)
      ..lineTo(s.width, s.height)
      ..lineTo(s.width - len, s.height)
      ..moveTo(len, s.height)
      ..lineTo(0, s.height)
      ..lineTo(0, s.height - len);
    canvas.drawPath(path, p);
  }

  @override
  bool shouldRepaint(covariant _BracketPainter o) => o.color != color || o.len != len;
}

/// قاب «هدف‌گیری» دور تصویر
class Bracket extends StatelessWidget {
  const Bracket({super.key, required this.child, this.color = V.cyan, this.len = 14, this.pad = 0});
  final Widget child;
  final Color color;
  final double len;
  final double pad;
  @override
  Widget build(BuildContext context) => Stack(
        fit: StackFit.passthrough,
        children: [
          Padding(padding: EdgeInsets.all(pad), child: child),
          Positioned.fill(child: IgnorePointer(child: CustomPaint(painter: _BracketPainter(color, len)))),
        ],
      );
}

/// فایل‌ها پیش‌فرض محو هستند؛ نگه‌داشتن انگشت = نمایش
class HiddenMedia extends StatefulWidget {
  const HiddenMedia({super.key, required this.child, this.sigma = 20, this.hint = true});
  final Widget child;
  final double sigma;
  final bool hint;
  @override
  State<HiddenMedia> createState() => _HiddenMediaState();
}

class _HiddenMediaState extends State<HiddenMedia> {
  bool _hold = false;
  @override
  Widget build(BuildContext context) => ListenableBuilder(
        listenable: Security.i,
        builder: (c, _) {
          final hide = Security.i.hideMedia && !Security.i.revealAll && !_hold;
          return GestureDetector(
            onLongPressStart: (_) => setState(() => _hold = true),
            onLongPressEnd: (_) => setState(() => _hold = false),
            onLongPressCancel: () => setState(() => _hold = false),
            child: hide
                ? ClipRect(
                    child: Stack(fit: StackFit.passthrough, children: [
                      ImageFiltered(
                        imageFilter: ImageFilter.blur(sigmaX: widget.sigma, sigmaY: widget.sigma, tileMode: TileMode.decal),
                        child: widget.child,
                      ),
                      Positioned.fill(child: Container(color: const Color(0xB004070C))),
                      if (widget.hint)
                        const Positioned.fill(child: Center(child: Icon(Icons.fingerprint, color: V.silverDim, size: 22))),
                    ]),
                  )
                : widget.child,
          );
        },
      );
}

class PersonAvatar extends StatelessWidget {
  const PersonAvatar({super.key, required this.person, this.size, this.bracket = false});
  final Person person;
  final double? size;
  final bool bracket;

  Widget _initials() => Container(
        color: V.cardHi,
        alignment: Alignment.center,
        child: person.name.trim().isEmpty
            ? const Icon(Icons.person_outline, color: V.silverDim)
            : Text(person.name.trim().characters.first,
                style: TextStyle(color: V.silver, fontSize: (size ?? 80) * 0.42, fontWeight: FontWeight.w700)),
      );

  @override
  Widget build(BuildContext context) {
    final Widget img = person.photo == null
        ? _initials()
        : HiddenMedia(
            hint: false,
            sigma: 14,
            child: Image.file(
              File(Vault.path(person.photo!)),
              fit: BoxFit.cover,
              cacheWidth: 400,
              errorBuilder: (_, __, ___) => _initials(),
            ),
          );
    Widget w = ClipPath(
      clipper: ShapeBorderClipper(shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular((size ?? 80) * 0.2))),
      child: SizedBox(width: size, height: size, child: img),
    );
    if (bracket) w = Bracket(pad: 5, color: V.confColors[person.conf.clamp(0, 3)], child: w);
    return w;
  }
}

class ConfChip extends StatelessWidget {
  const ConfChip(this.conf, {super.key, this.small = false});
  final int conf;
  final bool small;
  @override
  Widget build(BuildContext context) {
    final c = V.confColors[conf.clamp(0, 3)];
    return Container(
      padding: EdgeInsets.symmetric(horizontal: small ? 6 : 9, vertical: small ? 2 : 4),
      decoration: ShapeDecoration(
        color: V.a(c, .14),
        shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(6), side: BorderSide(color: V.a(c, .6))),
      ),
      child: Text(V.confNames[conf.clamp(0, 3)], style: TextStyle(color: c, fontSize: small ? 10 : 12, fontWeight: FontWeight.w600)),
    );
  }
}

class RelChip extends StatelessWidget {
  const RelChip(this.rel, {super.key, this.small = false});
  final String rel;
  final bool small;
  @override
  Widget build(BuildContext context) {
    final c = V.relColors[rel] ?? V.silverDim;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: small ? 6 : 9, vertical: small ? 2 : 4),
      decoration: ShapeDecoration(
        color: V.a(c, .12),
        shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(6), side: BorderSide(color: V.a(c, .5))),
      ),
      child: Text('$rel · ${V.relNames[rel] ?? ''}', style: TextStyle(color: c, fontSize: small ? 10 : 12)),
    );
  }
}

class TagChip extends StatelessWidget {
  const TagChip(this.tag, {super.key, this.onTap});
  final String tag;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
          decoration: BoxDecoration(border: Border.all(color: V.stroke), color: V.bg2),
          child: Text(tag, style: const TextStyle(color: V.cyan, fontSize: 12)),
        ),
      );
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 44, color: V.stroke),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(color: V.textDim, height: 1.7)),
          ]),
        ),
      );
}

class VField extends StatelessWidget {
  const VField({
    super.key,
    required this.controller,
    required this.label,
    this.hint,
    this.maxLines = 1,
    this.keyboard,
    this.onChanged,
    this.ltr = false,
    this.obscure = false,
  });
  final TextEditingController controller;
  final String label;
  final String? hint;
  final int maxLines;
  final TextInputType? keyboard;
  final ValueChanged<String>? onChanged;
  final bool ltr;
  final bool obscure;

  @override
  Widget build(BuildContext context) {
    final border = OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: V.stroke));
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLines: obscure ? 1 : maxLines,
        minLines: maxLines > 1 ? 3 : 1,
        obscureText: obscure,
        keyboardType: maxLines > 1 ? TextInputType.multiline : keyboard,
        textDirection: ltr ? TextDirection.ltr : null,
        onChanged: onChanged,
        style: const TextStyle(color: V.text),
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          labelStyle: const TextStyle(color: V.textDim),
          hintStyle: const TextStyle(color: V.stroke),
          filled: true,
          fillColor: V.card,
          enabledBorder: border,
          border: border,
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: V.accent)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        ),
      ),
    );
  }
}

class VButton extends StatelessWidget {
  const VButton({super.key, required this.label, this.icon, this.onTap, this.filled = true, this.danger = false, this.expand = false});
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final bool filled;
  final bool danger;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final c = danger ? V.danger : V.accent;
    final enabled = onTap != null;
    return Opacity(
      opacity: enabled ? 1 : .45,
      child: Material(
        color: filled ? V.a(c, .2) : Colors.transparent,
        shape: BeveledRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: c)),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                if (icon != null) ...[Icon(icon, size: 18, color: danger ? V.danger : V.cyan), const SizedBox(width: 8)],
                Text(label, style: TextStyle(color: danger ? V.danger : V.text, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ConfSelector extends StatelessWidget {
  const ConfSelector({super.key, required this.value, required this.onChanged});
  final int value;
  final ValueChanged<int> onChanged;
  @override
  Widget build(BuildContext context) => Row(
        children: [
          for (var i = 0; i < 4; i++)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Material(
                  color: value == i ? V.a(V.confColors[i], .2) : V.card,
                  shape: BeveledRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: BorderSide(color: value == i ? V.confColors[i] : V.stroke),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => onChanged(i),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Center(
                        child: Text(V.confNames[i],
                            style: TextStyle(color: value == i ? V.confColors[i] : V.textDim, fontSize: 12, fontWeight: FontWeight.w600)),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      );
}

class RelSelector extends StatelessWidget {
  const RelSelector({super.key, required this.value, required this.onChanged});
  final String value;
  final ValueChanged<String> onChanged;
  @override
  Widget build(BuildContext context) => Row(
        children: [
          for (final k in V.relNames.keys)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: Material(
                  color: value == k ? V.a(V.relColors[k]!, .18) : V.card,
                  shape: BeveledRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: BorderSide(color: value == k ? V.relColors[k]! : V.stroke),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: InkWell(
                    onTap: () => onChanged(k),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Column(children: [
                        Text(k, style: V.mono(size: 12, color: value == k ? V.relColors[k]! : V.textDim)),
                        const SizedBox(height: 3),
                        Text(V.relNames[k]!, style: TextStyle(color: value == k ? V.text : V.textDim, fontSize: 10)),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
        ],
      );
}

// ───────────────────────── انتخاب تاریخ شمسی ─────────────────────────

Future<DateTime?> pickJalali(BuildContext context, DateTime initial) => showModalBottomSheet<DateTime>(
      context: context,
      backgroundColor: V.card,
      builder: (_) => _JalaliSheet(initial: initial),
    );

class _JalaliSheet extends StatefulWidget {
  const _JalaliSheet({required this.initial});
  final DateTime initial;
  @override
  State<_JalaliSheet> createState() => _JalaliSheetState();
}

class _JalaliSheetState extends State<_JalaliSheet> {
  late int _y;
  late int _m;
  late int _d;
  late final int _minY;
  late final FixedExtentScrollController _yc;
  late final FixedExtentScrollController _mc;
  late final FixedExtentScrollController _dc;

  @override
  void initState() {
    super.initState();
    final j = Jalali.fromDateTime(widget.initial);
    _y = j.year;
    _m = j.month;
    _d = j.day;
    _minY = Jalali.now().year - 60;
    _yc = FixedExtentScrollController(initialItem: (_y - _minY).clamp(0, 70));
    _mc = FixedExtentScrollController(initialItem: _m - 1);
    _dc = FixedExtentScrollController(initialItem: _d - 1);
  }

  @override
  void dispose() {
    _yc.dispose();
    _mc.dispose();
    _dc.dispose();
    super.dispose();
  }

  Widget _wheel(FixedExtentScrollController c, int count, String Function(int) label, ValueChanged<int> on) =>
      CupertinoPicker(
        scrollController: c,
        itemExtent: 38,
        backgroundColor: Colors.transparent,
        onSelectedItemChanged: on,
        children: [
          for (var i = 0; i < count; i++)
            Center(child: Text(label(i), style: const TextStyle(color: V.text, fontSize: 18))),
        ],
      );

  @override
  Widget build(BuildContext context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('انتخاب تاریخ', style: TextStyle(color: V.text, fontSize: 16, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            SizedBox(
              height: 170,
              child: Directionality(
                textDirection: TextDirection.ltr,
                child: Row(children: [
                  Expanded(child: _wheel(_yc, 71, (i) => faDigits(_minY + i), (i) => _y = _minY + i)),
                  Expanded(child: _wheel(_mc, 12, (i) => jalaliMonths[i], (i) => _m = i + 1)),
                  Expanded(child: _wheel(_dc, 31, (i) => faDigits(i + 1), (i) => _d = i + 1)),
                ]),
              ),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: VButton(
                  label: 'تأیید',
                  icon: Icons.check,
                  expand: true,
                  onTap: () {
                    final len = Jalali(_y, _m, 1).monthLength;
                    final j = Jalali(_y, _m, _d > len ? len : _d);
                    final t = widget.initial;
                    final g = j.toDateTime();
                    Navigator.pop(context, DateTime(g.year, g.month, g.day, t.hour, t.minute));
                  },
                ),
              ),
              const SizedBox(width: 10),
              VButton(label: 'اکنون', filled: false, onTap: () => Navigator.pop(context, DateTime.now())),
            ]),
          ]),
        ),
      );
}
