import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/security.dart';
import 'shell.dart';

/// اسپلش: ظاهر شدن لوگو + خط اسکن آبی
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});
  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 2400));

  @override
  void initState() {
    super.initState();
    _c.forward().whenComplete(_go);
  }

  void _go() {
    if (!mounted) return;
    Security.i.markStarted();
    Navigator.pushReplacement(
      context,
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 500),
        pageBuilder: (_, __, ___) => const Shell(),
        transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
      ),
    );
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const size = 260.0;
    return Scaffold(
      backgroundColor: V.bg,
      body: Center(
        child: AnimatedBuilder(
          animation: _c,
          builder: (c, _) {
            final t = _c.value;
            final fade = Curves.easeOut.transform((t / 0.45).clamp(0.0, 1.0));
            final scan = ((t - 0.25) / 0.5).clamp(0.0, 1.0);
            final text = ((t - 0.6) / 0.3).clamp(0.0, 1.0);
            return Column(mainAxisSize: MainAxisSize.min, children: [
              Opacity(
                opacity: fade,
                child: Transform.scale(
                  scale: 0.9 + 0.1 * fade,
                  child: SizedBox(
                    width: size,
                    height: size,
                    child: Stack(children: [
                      Image.asset('assets/logo/vex_logo.png', width: size, height: size),
                      if (scan > 0 && scan < 1)
                        Positioned(
                          left: 0,
                          right: 0,
                          top: scan * size,
                          child: Container(
                            height: 3,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(colors: [Colors.transparent, V.cyan, Colors.transparent]),
                              boxShadow: [BoxShadow(color: V.a(V.cyan, .7), blurRadius: 14)],
                            ),
                          ),
                        ),
                    ]),
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Opacity(opacity: text, child: Text('VEX', style: V.mono(size: 26, color: V.silver, spacing: 14))),
              const SizedBox(height: 8),
              Opacity(opacity: text, child: Text('INTELLIGENCE ARCHIVE', style: V.mono(size: 8, color: V.silverDim, spacing: 4))),
            ]);
          },
        ),
      ),
    );
  }
}
